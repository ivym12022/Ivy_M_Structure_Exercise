import UIKit

import UIKit

struct engine {
    var engineOne : String
    var engineTwo : String
    var engineThree : String
}
var EngineInCar = engine(engineOne: "v4", engineTwo: "v6", engineThree: "v8")

print (EngineInCar.engineOne)
